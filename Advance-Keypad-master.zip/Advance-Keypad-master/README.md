# Advance-Keypad
Implementation of "Smart-Numpad" in smartphones using Tries. User types in telephone keypad and is accordingly given suggested contacts.
For example, if user types '666' one of the suggested contact will be 'MOM'(since 6 maps to 'mno' on modern keypad).
